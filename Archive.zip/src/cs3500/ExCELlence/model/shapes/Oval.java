package cs3500.ExCELlence.model.shapes;

public class Oval extends ShapeImpl implements Shape {
  public void draw() {
    // Implementation-dependent of oval shape, not yet clear of how to draw the shape

  }
}
