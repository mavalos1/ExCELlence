package cs3500.ExCELlence.model.shapes;

public class Rectangle extends ShapeImpl implements Shape {
  public void draw() {
    // Implementation-dependent of rectangle shape, not yet clear of how to draw the shape

  }
}
